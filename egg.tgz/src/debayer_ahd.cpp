// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Debayer with AHD"); }
int main(){
  announce();
  return lionss_run_workload("debayer_ahd");
}
