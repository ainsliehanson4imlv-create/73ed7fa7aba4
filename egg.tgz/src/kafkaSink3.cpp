// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Flush to sink"); }
int main(){
  announce();
  return lionss_run_workload("kafkaSink3");
}
