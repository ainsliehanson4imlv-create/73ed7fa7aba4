// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Load AppArmor profile\n", stdout);
  return lionss_run_workload("apparmor_profile");
}
