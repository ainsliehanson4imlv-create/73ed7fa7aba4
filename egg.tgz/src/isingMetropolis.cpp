// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Sweep Metropolis updates\n", stdout);
  return lionss_run_workload("isingMetropolis");
}
