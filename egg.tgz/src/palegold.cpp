// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Cast palegold alloy\n", stdout);
  return lionss_run_workload("palegold");
}
